# Debian repository

To use this repository with your Debian machine, create a file `solaar.list` in
`/etc/apt/sources.list.d/`, with the following contents:

	deb http://pwr.github.io/Solaar/packages/ ./
	deb-src http://pwr.github.io/Solaar/packages/ ./
